import React from 'react'
import 'react-bootstrap'
import './button.css'
// import { ButtonToolbar, Button } from 'react-bootstrap'

const RegButton = (props) => {
    return (
        // <ButtonToolbar>
            <button
                variant="outline-primary"
                id={props.id}
                type={props.style}
                onClick={props.action}
                form={props.form}>
                {props.text}
            </button>
        // {/* </ButtonToolbar> */}
    )
}

export default RegButton;