import React from 'react'
import 'react-bootstrap'
import './registrationform.css'
import Input from '../Input/Input'
import RegButton from "../Button/RegButton";

class RegistrationForm extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            usernameValue: '',
            nameValue: '',
            surnameValue: '',
            emailValue: '',
            passwordValue: '',
            confirmPasswordValue: ''
        }
        this.handleUsernameChange = this.handleUsernameChange.bind(this)
        this.handleNameChange = this.handleNameChange.bind(this)
        this.handleSurnameChange = this.handleSurnameChange.bind(this)
        this.handleEmailChange = this.handleEmailChange.bind(this)
        this.handlePasswordChange = this.handlePasswordChange.bind(this)
        this.handleConfirmPasswordChange = this.handleConfirmPasswordChange.bind(this)
    }

    handleUsernameChange(e) {
        let currentValue = e.target.value;
        this.setState(prevState => ({
            ...prevState, usernameValue: currentValue
        }))

    }

    handleNameChange(e) {
        let currentValue = e.target.value;
        this.setState(prevState => ({
            ...prevState, nameValue: currentValue
        }))
    }

    handleSurnameChange(e) {
        let currentValue = e.target.value;
        this.setState(prevState => ({
            ...prevState, surnameValue: currentValue
        }))
    }

    handleEmailChange(e) {
        let currentValue = e.target.value;
        this.setState(prevState => ({
            ...prevState, emailValue: currentValue
        }))
    }

    handlePasswordChange(e) {
        let currentValue = e.target.value;
        this.setState(prevState => ({
            ...prevState, passwordValue: currentValue
        }))
    }

    handleConfirmPasswordChange(e) {
        let currentValue = e.target.value;
        this.setState(prevState => ({
            ...prevState, confirmPasswordValue: currentValue
        }))
    }
    check = e => {
        e.preventDefault();
        console.log(this.state.usernameValue);
        console.log(this.state.nameValue)
        console.log(this.state.surnameValue)
        console.log(this.state.emailValue)
        console.log(this.state.passwordValue)
        console.log(this.state.confirmPasswordValue)
    }


    render() {
        return (
            <form className='registration-form'>
                <h3>Register</h3>

                <Input
                    type={'username'}
                    name={'username-field'}
                    // value={this.state.usernameValue}
                    placeholder={'Enter your username'}
                    handleChange={this.handleUsernameChange}
                /> {/* Input username */}

                <Input
                    type={'name'}
                    name={'name-field'}
                    value={this.state.nameValue}
                    placeholder={'Enter your name'}
                    handleChange={this.handleNameChange}
                /> {/* Input name */}

                <Input
                    type={'surname'}
                    name={'surname-field'}
                    value={this.state.surnameValue}
                    placeholder={'Enter your surname'}
                    handleChange={this.handleSurnameChange}
                /> {/* Input surname */}

                <Input
                    type={'email'}
                    name={'email-field'}
                    value={this.state.emailValue}
                    placeholder={'Enter your email'}
                    handleChange={this.handleEmailChange}
                /> {/* Input email */}

                <Input
                    type={'password'}
                    name={'password-field'}
                    value={this.state.passwordValue}
                    placeholder={'Enter your password'}
                    handleChange={this.handlePasswordChange}
                /> {/* Input password */}

                <Input
                    type={'password'}
                    name={'confirm-password-field'}
                    value={this.state.confirmPasswordValue}
                    placeholder={'Confirm your password'}
                    handleChange={this.handleConfirmPasswordChange}
                /> {/* Confirm password */}

                <RegButton
                    id={'register'}
                    // style={'submit'}
                    action={this.check}
                    text={'Register'}
                    form={'registration-form'}
                /> {/* Send data */}
            </form>
        )
    }
}

export default RegistrationForm;
