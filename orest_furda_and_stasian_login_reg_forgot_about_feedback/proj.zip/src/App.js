import React from 'react';
import './main.css'
import 'react-bootstrap'
import RegistrationForm from './components/RegistrationForm/RegistrationForm';


function App() {
  return (
    <div className="App">
      <RegistrationForm />
    </div>
  );
}

export default App;
